import java.util.Scanner; // Importar a ferramenta para leitura de dados escrito no terminal ou tela.
public class CalculadoraMedia {

    public static void main (String[] args) {
        // Criando o objeto Scanner para ler o que o usuário digita
        Scanner leitor = new Scanner(System.in);

        // 1. Entrada de dados
        System.out.print("Digite a nota 1: ");
        double n1 = leitor.nextDouble();

        System.out.print("Digite a nota 2: ");
        double n2 = leitor.nextDouble();

        System.out.print("Digite a nota 3: ");
        double n3 = leitor.nextDouble();

        System.out.print("Digite a nota 4: ");
        double n4 = leitor.nextDouble();

        // 2. Calcular o Processamento (Cálculo da Média)
        double media = (n1 + n2 + n3 + n4) / 4;

        //Exibir o resultado da média passada no Scan do terminal.
        System.out.printf("\nMédia final: %.2f\n" , media); //printf apresenta cálculo no terminal se for ln da erro.

        // 3.EStrutura Condicional
        if (media >= 7.0) {
            System.out.println("Status: APROVADO");
        }else if (media >= 5.0 && media < 7.0){
            System.out.println("Staus: EXAME");
        }else {
            System.out.println("Status: REPROVADO");
        }

        leitor.close(); // Fechar o scanner por ser uma boa prática.
    }
}
